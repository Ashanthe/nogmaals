counter = 50

while counter <= 1000:
    print(counter)
    counter += 1

print("Exit")

