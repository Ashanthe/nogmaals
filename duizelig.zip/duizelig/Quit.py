x = 1

while x < 6:
    print(x)
    x == input("Choose a color: ")
    if x == "quit":
        break
    x += 1
print("quit") 







