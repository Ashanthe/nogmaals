a = 20
while a <= 50:
    a = a+2
    print(a)
