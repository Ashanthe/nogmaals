a = 1
b = 1
while a <= 12:
    print(str(i) + "AM")
    a = a + 1

while b <= 12:
    print(str(x)+"PM")
    b = b + 1

